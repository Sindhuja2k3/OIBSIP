document.getElementById('convert').onclick=tempconvert;
document.getElementById('reset').onclick=resetfunc;

function tempconvert(){
    var fahrenheit=document.getElementById("fah").value;
    var celcius=document.getElementById("cel").value;
    var kelvin=document.getElementById("kel").value;
    if(fahrenheit!=''){
        celcius=(parseFloat(fahrenheit)-32)/1.8;
        kelvin=((parseFloat(fahrenheit)-32)/1.8)+273.15;

    }
    else if(celcius!=''){
        fahrenheit=(parseFloat(celcius)*1.8)+32;
        kelvin=parseFloat(celcius)+273.15;
    }
    else(kelvin!='')
    {
        fahrenheit=((parseFloat(kelvin)-273.15)*1.8)+32;
        celcius=parseFloat(kelvin)-273.15;
    }
    document.getElementById('fah').value=parseFloat(fahrenheit).toFixed(2);
    document.getElementById('cel').value=parseFloat(celcius).toFixed(2);
    document.getElementById('kel').value=parseFloat(kelvin).toFixed(2);
}
function resetfunc(){
    document.getElementById('fah').value='';
    document.getElementById('cel').value='';
    document.getElementById('kel').value='';

}